/* File Name: GraphicsWorld.h
* Lab # and Assignment #: Lab #5
* Lab section: 1
* Completed by: Graydon Hall and Jared Kraus
* Submission Date: 2021-10-25
*/

#ifndef GRAPHICS_WORLD
#define GRAPHICS_WORLD

class GraphicsWorld{
public:
    void run();

};
    

#endif